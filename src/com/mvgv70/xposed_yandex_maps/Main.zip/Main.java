package com.mvgv70.xposed_yandex_maps;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.util.Log;
import android.widget.ImageButton;

public class Main implements IXposedHookLoadPackage {
	
  private static ImageButton compassButton = null;
  private static ImageButton findmeButton = null;
  private final static String TAG = "xposed-yandex-maps";
	
  @Override
  public void handleLoadPackage(LoadPackageParam lpparam) throws Throwable {
    
    // FindMeButton(Context, AttributeSet)
    XC_MethodHook createFindMeButton = new XC_MethodHook() {
      
      @Override
      protected void afterHookedMethod(MethodHookParam param) throws Throwable {
        Log.d(TAG,"FindMeButton.create");
        findmeButton = (ImageButton)param.thisObject;
      }
    };    
    
    // CompassButton(Context, AttributeSet)
    XC_MethodHook createCompassButton = new XC_MethodHook() {
      
      @Override
      protected void afterHookedMethod(MethodHookParam param) throws Throwable {
        Log.d(TAG,"CompassButton.create");
        compassButton = (ImageButton)param.thisObject;
      }
    };
    
    final Handler handler = new Handler() {
    	
      @Override
      public void handleMessage(Message msg) {
        findmeButton.performClick();
        Log.d(TAG,"findmeButton pressed");
      }
    };
    
    // MapActivity.onCreate(Bundle)
    XC_MethodHook createActivity = new XC_MethodHook() {
      
      @Override
      protected void afterHookedMethod(MethodHookParam param) throws Throwable {
        Log.d(TAG,"Activity.create");
        //
        if (findmeButton != null)
        {
          Log.d(TAG,"findmeButton.visible="+findmeButton.getVisibility());
        }
        else
          Log.d(TAG,"findmeButton not found");
        //
        if (compassButton != null)
        {
          Log.d(TAG,"compassButton.visible="+compassButton.getVisibility());
        }
        else
          Log.d(TAG,"compassButton not found");
      }
    };
    
    // MapActivity.onStart()
    XC_MethodHook startActivity = new XC_MethodHook() {
      
      @Override
      protected void afterHookedMethod(MethodHookParam param) throws Throwable {
        Log.d(TAG,"Activity.start");
        //
        if (findmeButton != null)
        {
          Log.d(TAG,"findmeButton.visible="+findmeButton.getVisibility());
          // TODO: �������� ���� visible
          handler.sendEmptyMessageDelayed(0, 2000);
        }
        else
          Log.d(TAG,"findmeButton not found");
        //
        if (compassButton != null)
        {
          Log.d(TAG,"compassButton.visible="+compassButton.getVisibility());
          // compassButton.performClick();
        }
        else
          Log.d(TAG,"compassButton not found");
      }
    };   
    
    // begin hooks
    if (!lpparam.packageName.equals("ru.yandex.yandexmaps")) return;
    XposedHelpers.findAndHookConstructor("ru.yandex.yandexmaps.gui.FindMeButton", lpparam.classLoader, Context.class, AttributeSet.class, createFindMeButton);
    XposedHelpers.findAndHookConstructor("ru.yandex.yandexmaps.gui.CompassButton", lpparam.classLoader, Context.class, AttributeSet.class, createCompassButton);
    XposedHelpers.findAndHookMethod("ru.yandex.yandexmaps.MapActivity", lpparam.classLoader, "onCreate", Bundle.class,  createActivity);
    XposedHelpers.findAndHookMethod("ru.yandex.yandexmaps.MapActivity", lpparam.classLoader, "onStart", startActivity);
    Log.d(TAG,"ru.yandex.yandexmaps OK");
  }
  

}